﻿using UnityEngine;
using LuaInterface;

public class LuaPerfectTest_ToLua : MonoBehaviour
{
    LuaState lua = null;

    LuaFunction luaStart = null;
    LuaFunction luaUpdate = null;
    LuaFunction luaOnDestroy = null;

    void Start()
    {
        lua = new LuaState();
        lua.Start();
        lua.AddSearchPath(Application.dataPath + "/ToLua/Examples/00_LuaPerfectTest_ToLua");
        LuaBinder.Bind(lua);
        lua.DoFile("LuaPerfectTest_ToLua.lua");

        luaStart = lua.GetFunction("start");
        luaUpdate = lua.GetFunction("update");
        luaOnDestroy = lua.GetFunction("onDestroy");

        luaStart.Call();
    }

    void Update()
    {
        luaUpdate.Call();
    }

    void OnDestroy()
    {
        luaOnDestroy.Call();
        lua.Dispose();
        lua = null;
    }
}
