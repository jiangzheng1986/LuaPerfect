﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LuaInterface;

public class LuaPerfectTest_ULua : MonoBehaviour {

    LuaState lua = null;

    LuaFunction luaStart = null;
    LuaFunction luaUpdate = null;
    LuaFunction luaOnDestroy = null;

    void Start () {
        lua = new LuaState();
        string path = Application.dataPath + "/uLua/Examples/00_LuaPerfectTest_ULua/LuaPerfectTest_ULua.lua";
        lua.DoFile(path);

        luaStart = lua.GetFunction("start");
        luaUpdate = lua.GetFunction("update");
        luaOnDestroy = lua.GetFunction("onDestroy");

        luaStart.Call();
    }
	
	void Update () {
        luaUpdate.Call();
    }

    void OnDestroy()
    {
        luaOnDestroy.Call();
        lua.Dispose();
        lua = null;
    }
}
